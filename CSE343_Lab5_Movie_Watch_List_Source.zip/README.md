# CSE343 Lab 5 — Movie Watch List

A React-based movie watch-list application built for the **CSE343 Web Development Lab 5** task.

## Features

- Add a movie with title, year, and genre.
- Remove an individual movie from the list.
- Write or update a review comment for each movie.
- Assign or change a rating from 1–5 stars.
- Display each rating visually with star emojis.
- Show list count and average rating.
- Save the current list in browser `localStorage` so it remains available after refresh.

## Run locally

```bash
npm install
npm run dev
```

Open the local Vite URL shown in the terminal. Create a production build with:

```bash
npm run build
```

## Main files

- `src/App.jsx` — React components, form handling, list state, ratings, reviews, and persistence.
- `src/styles.css` — responsive Popcorn Notebook design system.
- `src/main.jsx` — React entry point.
- `public/manus-routes.json` — single-page route declaration.

## Lab submission checklist

1. Submit the public GitHub repository link.
2. Submit the completed lab report document.
3. Include the application screenshot and code/IDE screenshots from the report.
4. Confirm the repository opens without requiring a login.
5. Include the `npm install` and `npm run dev` commands if the instructor wants to run the project.
