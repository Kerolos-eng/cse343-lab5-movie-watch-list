from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.section import WD_SECTION
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.enum.table import WD_TABLE_ALIGNMENT, WD_CELL_VERTICAL_ALIGNMENT
from docx.enum.style import WD_STYLE_TYPE
from pathlib import Path

ROOT = Path('/home/ubuntu/movielist')
OUT = ROOT / 'CSE343_Lab5_Report.docx'
doc = Document()
sec = doc.sections[0]
sec.top_margin = Inches(.65); sec.bottom_margin = Inches(.65); sec.left_margin = Inches(.75); sec.right_margin = Inches(.75)

styles = doc.styles
styles['Normal'].font.name = 'Aptos'; styles['Normal'].font.size = Pt(10.5)
for name, size, color in [('Title', 28, '252326'), ('Heading 1', 17, 'C9362B'), ('Heading 2', 12.5, '252326')]:
    st = styles[name]; st.font.name = 'Aptos Display'; st.font.size = Pt(size); st.font.bold = True; st.font.color.rgb = RGBColor.from_string(color)

# Header/footer
header = sec.header.paragraphs[0]
header.text = 'CSE343 · WEB DEVELOPMENT · LAB 5'
header.alignment = WD_ALIGN_PARAGRAPH.RIGHT
header.runs[0].font.size = Pt(8); header.runs[0].font.bold = True; header.runs[0].font.color.rgb = RGBColor(201,54,43)
footer = sec.footer.paragraphs[0]
footer.alignment = WD_ALIGN_PARAGRAPH.CENTER
footer.add_run('Movie Watch List  |  React submission  |  ')
field = OxmlElement('w:fldSimple'); field.set(qn('w:instr'), 'PAGE'); footer._p.append(field)
for r in footer.runs: r.font.size = Pt(8); r.font.color.rgb = RGBColor(120,110,104)

def shade(cell, fill):
    tcPr = cell._tc.get_or_add_tcPr(); shd = OxmlElement('w:shd'); shd.set(qn('w:fill'), fill); tcPr.append(shd)

def set_cell_text(cell, text, bold=False, color='252326'):
    cell.text = ''
    p = cell.paragraphs[0]; r = p.add_run(text); r.bold = bold; r.font.size = Pt(9); r.font.color.rgb = RGBColor.from_string(color)
    cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER

def add_caption(text):
    p = doc.add_paragraph(); p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r = p.add_run(text); r.italic = True; r.font.size = Pt(8.5); r.font.color.rgb = RGBColor(110,100,94)

# Cover
p = doc.add_paragraph(); p.alignment = WD_ALIGN_PARAGRAPH.CENTER
r = p.add_run('CSE343'); r.bold = True; r.font.size = Pt(12); r.font.color.rgb = RGBColor(201,54,43)
p = doc.add_paragraph(); p.style = 'Title'; p.alignment = WD_ALIGN_PARAGRAPH.CENTER; p.add_run('Lab 5 Report')
p = doc.add_paragraph(); p.alignment = WD_ALIGN_PARAGRAPH.CENTER
r = p.add_run('Intro to React · Movie Watch List'); r.font.size = Pt(17); r.bold = True; r.font.color.rgb = RGBColor(201,54,43)
p = doc.add_paragraph(); p.alignment = WD_ALIGN_PARAGRAPH.CENTER
r = p.add_run('A React application for saving movies, reviews, and ratings.'); r.font.size = Pt(11); r.italic = True

t = doc.add_table(rows=4, cols=2); t.alignment = WD_TABLE_ALIGNMENT.CENTER; t.style = 'Table Grid'
rows = [('Course', 'CSE343 Web Development'), ('Lab', 'Lab 5 — Intro to React'), ('Project', 'Movie Watch List'), ('Prepared for', 'Instructor submission')]
for i,(a,b) in enumerate(rows):
    set_cell_text(t.cell(i,0), a, True, 'C9362B'); set_cell_text(t.cell(i,1), b)
    shade(t.cell(i,0), 'FFF0E8')

doc.add_paragraph('')
p = doc.add_paragraph(); p.alignment = WD_ALIGN_PARAGRAPH.CENTER
r = p.add_run('Submission package'); r.bold = True; r.font.size = Pt(12)
p = doc.add_paragraph(); p.alignment = WD_ALIGN_PARAGRAPH.CENTER
p.add_run('This report includes the completed app evidence, source-code evidence, setup instructions, and final submission requirements.').font.size = Pt(10)
doc.add_page_break()

# Summary
doc.add_heading('1. Lab task and implementation', level=1)
doc.add_paragraph('The Lab 5 task asks for a React-based Movies Watch List. The completed application is a responsive single-page interface where a user can add movies, remove them, write or update a review comment, assign a one-to-five-star rating, and see that rating represented with star emojis.')

t = doc.add_table(rows=1, cols=3); t.style='Table Grid'; t.alignment=WD_TABLE_ALIGNMENT.CENTER
for j,txt in enumerate(['Requirement','Implementation','Evidence']): set_cell_text(t.cell(0,j),txt,True,'FFFFFF'); shade(t.cell(0,j),'C9362B')
requirements=[('Add movies','Form accepts title, year, and genre and appends a new movie card.','New Entry panel'),('Remove movies','Each card has a Remove action that filters the selected movie.','Movie cards'),('Review comment','Each card has an editable review textarea.','Your review field'),('Star rating','Five interactive star buttons update the selected rating.','Give it a rating row'),('Emoji display','Each movie displays filled and empty star emojis for its rating.','Gold/outlined stars')]
for a,b,c in requirements:
    cells=t.add_row().cells; set_cell_text(cells[0],a,True); set_cell_text(cells[1],b); set_cell_text(cells[2],c)

doc.add_heading('2. Technology and project structure', level=1)
doc.add_paragraph('The project uses React with JSX and Vite. State is managed with React useState; useEffect persists the list in localStorage; useMemo calculates the average rating. The layout is styled with a responsive CSS file and remains usable on desktop and mobile screens.')
for line in ['src/App.jsx — components, movie state, add/remove actions, reviews, ratings, and emoji output.','src/main.jsx — React entry point.','src/styles.css — responsive Popcorn Notebook visual design.','public/manus-routes.json — single-page route declaration.','README.md — setup, feature summary, and submission notes.','evidence/ — application and source-code screenshots.']:
    doc.add_paragraph(line, style='List Bullet')

doc.add_heading('3. Running the project', level=1)
doc.add_paragraph('From the repository root, install dependencies and start the development server with the following commands:')
code = doc.add_paragraph(); code.paragraph_format.left_indent=Inches(.3); code.paragraph_format.space_after=Pt(10)
r=code.add_run('npm install\nnpm run dev\n\n# production check\nnpm run build'); r.font.name='Consolas'; r.font.size=Pt(9); r.font.color.rgb=RGBColor(50,50,50)
doc.add_paragraph('The production build was verified successfully with Vite. The application serves the root route and the required manus-routes.json file.')

# App screenshot
doc.add_heading('4. Application screenshots', level=1)
doc.add_paragraph('The desktop screenshot shows the finished interface with two sample movies, reviews, ratings, emoji display, list statistics, and the add-movie form. The mobile screenshot demonstrates the responsive single-column layout.')
doc.add_picture(str(ROOT/'evidence/app-desktop.png'), width=Inches(6.35)); add_caption('Figure 1. Completed Movie Watch List application — desktop view.')
doc.add_page_break()
doc.add_picture(str(ROOT/'evidence/app-mobile.png'), height=Inches(8.7)); add_caption('Figure 2. Completed Movie Watch List application — mobile view.')

# Code screenshots
doc.add_heading('5. Source-code screenshots', level=1)
doc.add_paragraph('The following IDE-style screenshots show the main React logic and the responsive stylesheet included in the repository.')
doc.add_picture(str(ROOT/'evidence/code-app-jsx.png'), width=Inches(6.35)); add_caption('Figure 3. App.jsx source evidence — React state, Stars component, persistence, and addMovie logic.')
doc.add_page_break()
doc.add_picture(str(ROOT/'evidence/code-styles-css.png'), width=Inches(6.35)); add_caption('Figure 4. styles.css source evidence — layout, colors, cards, and responsive styling.')

# GitHub and checklist
doc.add_heading('6. GitHub repository and final submission requirements', level=1)
doc.add_paragraph('The project has been committed locally in Git. The intended public repository is:')
p = doc.add_paragraph(); r=p.add_run('https://github.com/Kerolos-eng/cse343-lab5-movie-watch-list'); r.bold=True; r.font.color.rgb=RGBColor(201,54,43)
status = doc.add_table(rows=2, cols=2); status.style='Table Grid'; status.alignment=WD_TABLE_ALIGNMENT.CENTER
set_cell_text(status.cell(0,0),'Repository status',True,'FFFFFF'); shade(status.cell(0,0),'C9362B'); set_cell_text(status.cell(0,1),'Pending GitHub repository-creation permission')
set_cell_text(status.cell(1,0),'Reason',True,'C9362B'); shade(status.cell(1,0),'FFF0E8'); set_cell_text(status.cell(1,1),'The authenticated CLI token currently lacks CreateRepository permission and the browser session is not signed in.')
doc.add_paragraph('Before submitting, complete the remaining GitHub action: create the repository above as Public, push the main branch, open the link in an incognito window to confirm it is visible without login, and replace the status note in this report with the confirmed public link.')
doc.add_heading('Final instructor submission checklist', level=2)
for line in ['Public GitHub repository link opens without login.','Lab report document is attached.','Application desktop screenshot is included.','Application mobile screenshot is included.','App.jsx source screenshot is included.','styles.css source screenshot is included.','README.md explains npm install and npm run dev.','Required behavior is demonstrated: add, remove, review, rating, and emoji display.']:
    doc.add_paragraph('☐ ' + line)

doc.add_heading('7. Conclusion', level=1)
doc.add_paragraph('The Lab 5 React task has been implemented as a complete, screenshot-ready Movie Watch List. It demonstrates reusable React components, JSX rendering, state updates, event handling, conditional list rendering, controlled form fields, browser persistence, and responsive CSS styling.')

doc.save(OUT)
print(OUT)
